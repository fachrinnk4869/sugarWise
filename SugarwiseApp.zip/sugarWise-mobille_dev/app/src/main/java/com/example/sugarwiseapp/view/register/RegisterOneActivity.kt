package com.example.sugarwiseapp.view.register

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.sugarwiseapp.R

class RegisterOneActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_one)
    }
}